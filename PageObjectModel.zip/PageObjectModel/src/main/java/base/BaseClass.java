package base;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.github.bonigarcia.wdm.WebDriverManager;
import utils.DataFromExcel;


public class BaseClass {
	
	public String excelFileName="";
	public static ExtentReports extent;
	public static ExtentTest test;
	public String testName, testDescription, testAuthor, testCategory;
	private static final ThreadLocal<RemoteWebDriver> remoteDriver= new ThreadLocal<RemoteWebDriver>();
	 
	public void setDriver() {
		remoteDriver.set(new ChromeDriver());
	}
	
	public RemoteWebDriver getDriver() {
		return remoteDriver.get();
	}
	
	
	@BeforeSuite
	public void startReport() {
	ExtentHtmlReporter reporter = new ExtentHtmlReporter("./reports/result.html");
	reporter.setAppendExisting(true);
	extent = new ExtentReports();
	extent.attachReporter(reporter);
	}
	
	
	@BeforeClass
	public void testCaseDetails() {
	test = extent.createTest(testName, testDescription);
	test.assignCategory(testCategory);
	test.assignAuthor(testAuthor);
	}
	
	@AfterSuite
	public void stopReport() {
	extent.flush();
	}
	
	@BeforeMethod
	public void browserSetUp() {
		WebDriverManager.chromedriver().setup();
		setDriver();
		getDriver().get("http://leaftaps.com/opentaps/control/login");
		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	@AfterMethod
	public void tearDown() {
		getDriver().quit();
	}
	
	@DataProvider(name="data")
	public String[][] dataset() throws IOException {
		String[][] data= DataFromExcel.readData(excelFileName);
		return data;
	}
	
}
