package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import base.BaseClass;
import pages.LoginPage;


public class VerifyLogin extends BaseClass {
	
	@BeforeTest
	public void excelName() {
		excelFileName="login";
		testName="verifylogin";
		testDescription="To login to leaftaps";
		testAuthor="Parvathi";
		testCategory="smoke";
	}
	
	@Test (dataProvider = "data")
	public void runLogin(String username, String password ) {
		
		LoginPage lp= new LoginPage();
		lp.typePassword(username);
		lp.typePassword(password);
		lp.clickLogin();
		
	}

}
