package stepDefinitions;

import org.openqa.selenium.By;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;

public class SalesForceLoginPage extends BaseClass {
	
	
	@Given ("Enter the username as {string}")
	public void typeUsername(String username) {
		driver.findElement(By.id("username")).sendKeys(username);
	}
	
	@And ("Enter the password as {string}")
	public void typePassword(String password) {
		driver.findElement(By.id("password")).sendKeys(password);
	}
	
	@And ("click on the login button")
	public void clickLogin() {
		driver.findElement(By.id("Login")).click();	
	}
	
}
