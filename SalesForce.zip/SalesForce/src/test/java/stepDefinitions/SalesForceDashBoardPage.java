package stepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import io.cucumber.java.en.And;

public class SalesForceDashBoardPage extends BaseClass {

	@And("click on the New Dashboard option")
	public void click_on_the_new_dashboard_option() {
	    driver.findElement(By.xpath("//div[text()='New Dashboard']")).click();
	}
	
	@And("enter Name as (.*)$")
	public void enterDashBoardName(String name) throws InterruptedException {
		WebElement frame = driver.findElement(By.xpath("//iframe[@title='dashboard']"));
		driver.switchTo().frame(frame);
		driver.findElement(By.xpath("//label[text()='Name']/following::input")).sendKeys(name);
		
	}
	
	@And("click on Create.")
	public void click_on_create() {
	    driver.findElement(By.xpath("//button[text()='Create']")).click();
	}
	
	@And("click on Save and Verify Dashboard name")
	public void clickVerifyDashboardName() throws InterruptedException {
		Thread.sleep(5000);
	    String title = driver.getTitle();
	    System.out.println(title);
	}
	
}
