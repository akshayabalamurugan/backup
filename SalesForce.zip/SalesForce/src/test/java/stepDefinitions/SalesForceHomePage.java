package stepDefinitions;

import org.openqa.selenium.By;
import io.cucumber.java.en.And;

public class SalesForceHomePage extends BaseClass {
	
	@And("click on toggle menu button from the left corner")
	public void clickOnToggleMenu() {
		driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
	}
	
	@And("click view All and click Sales from App Launcher")
	public void click_view_all_and_click_sales_from_app_launcher() {
		driver.findElement(By.xpath("//button[text()='View All']")).click();
		driver.findElement(By.xpath("//p[text()='Sales']")).click();
	}
	
	@And("click View All and click Dashboards from App Launcher")
	public void click_view_all_and_click_dashboards_from_app_launcher() throws InterruptedException {
		driver.findElement(By.xpath("//button[text()='View All']")).click();
		driver.findElement(By.xpath("//input[@class='slds-input']")).sendKeys("Dashboards");
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//mark[text()='Dashboards']/ancestor::span)[2]")).click();
	}

	@And("click View All and click Individuals from App Launcher")
	public void click_view_all_and_click_individuals_from_app_launcher() {
		driver.findElement(By.xpath("//button[text()='View All']")).click();
		driver.findElement(By.xpath("//input[@class='slds-input']")).sendKeys("Individuals");
		driver.findElement(By.xpath("//mark[text()='Individuals']")).click();
	}
	
	@And("click on Opportunity tab")
	public void click_on_opportunity_tab() {
		driver.findElement(By.xpath("//a[@class='slds-button slds-button_reset']")).click();
	}
	
	@And("click on Accounts tab")
	public void click_on_Accounts_tab() {
		driver.findElement(By.xpath("(//a[@class='slds-button slds-button_reset'])[5]")).click();
	}
}
