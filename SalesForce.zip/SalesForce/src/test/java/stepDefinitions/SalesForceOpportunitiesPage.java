package stepDefinitions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import io.cucumber.java.en.And;

public class SalesForceOpportunitiesPage extends BaseClass{
	
	public String opportunityName;

	@And("click on New button")
	public void click_on_new_button() {
		WebElement findElement = driver.findElement(By.xpath("//span[text()='New Opportunity']"));
		driver.executeScript("arguments[0].click();", findElement);
	}
	
	@And("enter Opportunity name as (.*)$")
	public void enterOpportunityName(String name) {
		driver.findElement(By.xpath("//label[text()='Opportunity Name']/following::input")).sendKeys(name);
		opportunityName= name;
	}
	
	@And("store the Opportunity name as (.*)$")
	public void storeOpportunityName(String name) {
		opportunityName= name;
	}
	
	
	@And("choose close date as Today")
	public void choose_close_date_as_today() throws InterruptedException {
		Thread.sleep(2000);
		driver.findElement(By.xpath("//label[text()='Close Date']/following::input")).click();
		driver.findElement(By.xpath("//button[text()='Today']")).click();
	}
	
	@And("select Stage as Need Analysis")
	public void select_stage_as_need_analysis() {
		driver.findElement(By.xpath("//button[contains(@class,'slds-combobox__input slds-input_faux')]")).click();
		driver.findElement(By.xpath("//span[@title='Needs Analysis']")).click();
	}
	
	@And("click Save and VerifyOppurtunity Name")
	public void click_save_and_verify_oppurtunity_name() throws InterruptedException {
		driver.findElement(By.xpath("//button[text()='Save']")).click();
		Thread.sleep(5000);
		String title = driver.getTitle();
		System.out.println(title);
		if (title.contains(opportunityName)) {
			System.out.println("The oppurtunity name is verified as correct");
		} 
		else {
			System.out.println("The oppurtunity name is verified as incorrect");
		}
	}
	
	@And ("click Save and Verify errormessage")
		public void saveAndVerifyError() {
		driver.findElement(By.xpath("//button[text()='Save']")).click();
		System.out.println("The error message is");
		String errorHead = driver.findElement(By.xpath("//div[@class='genericNotification']/strong")).getText();
		System.out.println(errorHead);
		List<WebElement> errors = driver.findElements(By.xpath("//ul[contains(@class,'errorsList slds-list_dotted')]//a"));
		for (int i = 0; i <errors.size(); i++) {
			String parameters = errors.get(i).getText();
			System.out.println(parameters);
		}
	}
	
	
}
