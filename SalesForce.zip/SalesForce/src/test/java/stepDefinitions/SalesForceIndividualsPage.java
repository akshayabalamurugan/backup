package stepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import io.cucumber.java.en.And;

public class SalesForceIndividualsPage extends BaseClass{
	
	@And("click on the Dropdown icon in the Individuals tab")
	public void click_on_the_dropdown_icon_in_the_individuals_tab() {
	    driver.findElement(By.xpath("//span[text()='Individuals Menu']//ancestor::a[@class='slds-button slds-button_reset']")).click();
	}
	
	@And("click on New Individual")
	public void click_on_new_individual() {
		WebElement findElement = driver.findElement(By.xpath("//span[text()='New Individual']"));
		driver.executeScript("arguments[0].click();", findElement);
	}
	
	@And("Enter the Last Name as (.*)$")
	public void enter_the_last_name(String name) {
		driver.findElement(By.xpath("//input[contains(@class,'lastName')]")).sendKeys(name);
	}
	
	@And("click save and verify Individuals Name")
	public void click_save_and_verify_individuals_name() throws InterruptedException {
		driver.findElement(By.xpath("(//span[text()='Save'])[2]")).click();
		Thread.sleep(5000);
		System.out.println(driver.getTitle());
	}
}
