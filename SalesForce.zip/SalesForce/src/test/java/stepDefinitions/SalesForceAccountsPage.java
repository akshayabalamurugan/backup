package stepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import io.cucumber.java.en.And;

public class SalesForceAccountsPage extends BaseClass {

	@And("click on New Accounts button")
	public void click_on_newAccounts_button() {
		WebElement findElement = driver.findElement(By.xpath("//span[text()='New Account']"));
		driver.executeScript("arguments[0].click();", findElement);
	}
	
	@And ("enter account name as (.*)$")
	public void enterAccountname(String name) {
		driver.findElement(By.xpath("//label[text()='Account Name']/following::input")).sendKeys(name);
	}
	
	@And("select Ownership as Public")
	public void selectOwnerShip() throws InterruptedException {
		Thread.sleep(3000);
		WebElement findElement2 = driver.findElement(By.xpath("//label[text()='Ownership']/following::button"));
		driver.executeScript("arguments[0].click();", findElement2);
		driver.findElement(By.xpath("//span[@title='Public']")).click();
	}
	
	@And("click save and verify Account name")
	public void saveAndVerify() throws InterruptedException {
		driver.findElement(By.xpath("//button[text()='Save']")).click();
		Thread.sleep(5000);
		System.out.println(driver.getTitle());
	}
}
