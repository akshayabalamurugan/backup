package hooks;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;

import io.cucumber.java.AfterStep;
import io.cucumber.java.BeforeStep;
import stepDefinition.BaseClass;

public class HooksImplementation extends BaseClass{
	
	@BeforeStep
	public void beforeStep() {
	System.out.println("This runs before each step in feature");
	}
	
	@AfterStep
	public void snapShot() throws IOException {
		System.out.println("This runs after each step in feature");
		 File source = driver.getScreenshotAs(OutputType.FILE);
		 File target= new File("snap"+i+".png");
		 FileUtils.copyFile(source, target);
		 i++;
	}

}
