package stepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import io.cucumber.java.en.And;
import io.cucumber.java.en.But;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class FindLeadsPage extends BaseClass {
	
	@And ("enter first name as (.*)$")
	public void enterNameinFindLead(String firstName) {
		driver.findElement(By.xpath("(//label[text()='First name:'])[3]/following::input")).sendKeys(firstName);
	}
	
	@And ("click find leads button")
	public void findLeads(){
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
	}
	
	@And ("capture the first resulting lead")
	public void captureLeadId() throws InterruptedException {
		Thread.sleep(3000);
		leadId = driver.findElement(By.xpath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId']//a)[1]")).getText();	
	}
	
	@And ("click on the first resulting lead")
	public void selectLead() throws InterruptedException {
		Thread.sleep(3000);
		driver.findElement(By.xpath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId']//a)[1]")).click();	
	}
	
	@And ("enter the captured first resulting lead id")
	public void findleadwithLeadId() {
		driver.findElement(By.xpath("(//label[text()='Lead ID:']/following::input)[1]")).sendKeys(leadId);
	}
	
	@And ("click on phone tab")
	public void clickPhoneTab()  {
		driver.findElement(By.xpath("//span[text()='Phone']")).click();
	}

	@And ("enter the country code as (.*)$")
	public void typeCountryCode(String countrycode) {
		driver.findElement(By.id("ext-gen262")).clear();
		driver.findElement(By.id("ext-gen262")).sendKeys(countrycode);	
	}
	
	@And ("enter the area code as (.*)$")
	public void typeAreaCode(String areacode) {
		driver.findElement(By.id("ext-gen266")).sendKeys(areacode);
	}
	
	@And ("enter the phone number as (.*)$")
	public void typePhoneNumber(String phoneNummer)  {
		driver.findElement(By.id("ext-gen270")).sendKeys(phoneNummer);
	}
	
	@And ("verify no records")
	public void verifyNorecords() throws InterruptedException  {
		Thread.sleep(3000);
		String message = driver.findElement(By.xpath("//div[@class='x-paging-info']")).getText();
		 System.out.println(message);
		if (message.equalsIgnoreCase("No records to display")) {
			System.out.println("The lead is deleted");	
		}
		else {
			System.out.println("The lead is not deleted");
		}
	}
}
