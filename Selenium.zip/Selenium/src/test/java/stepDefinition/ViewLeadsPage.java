package stepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import io.cucumber.java.en.And;
import io.cucumber.java.en.But;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ViewLeadsPage extends BaseClass {
	
	
	@And ("click on edit button")
	public void clickEdit() {
		driver.findElement(By.linkText("Edit")).click();
	}

	@And ("click on Duplicate button")
	public void clickDuplicate() {
		driver.findElement(By.linkText("Duplicate Lead")).click();
	}
	
	@And ("click on delete button")
	public void clickDelete() {
		driver.findElement(By.linkText("Delete")).click();
	}
	
	@Then ("verify the successful lead creation")
	public void verifyCreateLead() {
		String title=driver.getTitle();
		if (title.contains("View Lead")) {
			System.out.println("The lead is created successfully");
		}
		else {
			System.out.println("The lead is not created successfully");
		}
	}
	
	@Then ("verify whether the lead is updated")
	public void verifyUpdateLead() {
		String companyName = driver.findElement(By.id("viewLead_companyName_sp")).getText();
		if (companyName.contains(companyName)) {
			System.out.println("The company name is updated");
		}
		else {
			System.out.println("The company name is not updated");
		}
	}
	
	@Then ("verify whether the lead is deleted")
	public void verifydeleteLead() {
		String message = driver.findElement(By.xpath("//div[@class='x-paging-info']")).getText();
		 System.out.println(message);
		if (message.equalsIgnoreCase("No records to display")) {
			System.out.println("The lead is deleted");	
		}
		else {
			System.out.println("The lead is not deleted");
		}
	}
	
	@Then ("verify whether the lead is duplicated with companyname as (.*)$")
	public void verifyDuplicateLead(String newCompanyName) {
		String duplicateTitle=driver.getTitle();
		System.out.println("Page title after duplicate lead:"+duplicateTitle);
		String companyName = driver.findElement(By.id("viewLead_companyName_sp")).getText();
		if (companyName.contains(newCompanyName)) {
			System.out.println("The lead is duplicated successfully");
		}
		else {
			System.out.println("The lead is not duplicated successfully");
		}
		
	}
}
