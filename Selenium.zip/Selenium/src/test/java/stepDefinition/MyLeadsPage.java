package stepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import io.cucumber.java.en.And;
import io.cucumber.java.en.But;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MyLeadsPage extends BaseClass {
	
	@And ("click on create lead link")
	public void clickCreateLeadLink() {
		driver.findElement(By.linkText("Create Lead")).click();
	}
	
	@And ("click on find lead link")
	public void clickFindLeads() {
		driver.findElement(By.linkText("Find Leads")).click();	
	}
	
	@And ("click on merge lead link")
	public void clickMergeLeads() {
		driver.findElement(By.linkText("Merge Leads")).click();	
	}
}
