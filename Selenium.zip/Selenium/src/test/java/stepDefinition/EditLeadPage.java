package stepDefinition;

import org.openqa.selenium.By;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

public class EditLeadPage extends BaseClass {
	
	@And ("change the company name as (.*)$")
	public void updateCompanyName(String companyName) {
		driver.findElement(By.id("updateLeadForm_companyName")).clear();
		driver.findElement(By.id("updateLeadForm_companyName")).sendKeys(companyName);
	}
	
	@And ("click on update button")
	public void updateLead() {
		driver.findElement(By.className("smallSubmit")).click();
	}
}
