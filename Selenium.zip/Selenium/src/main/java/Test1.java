import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Test1 {

	public static void main(String[] args) throws MalformedURLException, IOException {
		// TODO Auto-generated method stub
		
		WebDriverManager.chromedriver().setup();
		
		HttpURLConnection huc = null;
		int respCode;
		
		ChromeOptions options= new ChromeOptions();
		options.setUnhandledPromptBehaviour(UnexpectedAlertBehaviour.ACCEPT);
		options.getCapability(null);
		
		
		options.setAcceptInsecureCerts(true);
		options.addArguments("--disable-notifications");
		ChromeDriver driver= new ChromeDriver(options);
		
		driver.get("https://www.leafground.com/link.xhtml");
		
		driver.manage().window().maximize();
		
		
		
		
		String attribute = driver.findElement(By.xpath("//a[text()='Broken?']")).getAttribute("href");
		
		
		
		huc = (HttpURLConnection)(new URL(attribute).openConnection());

		huc.setRequestMethod("GET");

		huc.connect();

		Alert alert= driver.switchTo().alert();
		alert.sendKeys(attribute);
		
		
		respCode = huc.getResponseCode();
		
		System.out.println(respCode);

	}

}
