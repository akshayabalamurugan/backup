import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List list1= Arrays.asList("Apple","Orange","Leamon","Grape","Banana");
		List list2= Arrays.asList("Orange","Banana");
		List list3= new ArrayList();
		
		for(int i=0; i<list1.size(); i++) {

			if (list2.contains(list1.get(i))) {
				
			} else {
				list3.add(list1.get(i));
			}
		}
		System.out.println(list3);
	}

}
