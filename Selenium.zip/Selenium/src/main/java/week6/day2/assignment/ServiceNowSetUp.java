package week6.day2.assignment;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ServiceNowSetUp {
	ChromeDriver driver;
	ChromeOptions options;
	WebDriverWait wait;
	
@Parameters({"url","username","password"})	
@BeforeMethod
	public void serviceNowLogin(String url, String username, String password) {
		WebDriverManager.chromedriver().setup();
		options= new ChromeOptions();
		options.addArguments("--disabled-notifications");
		driver= new ChromeDriver(options);
		wait= new WebDriverWait(driver,Duration.ofSeconds(30));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.get(url);
		driver.manage().window().maximize();
		driver.findElement(By.id("user_name")).sendKeys(username);
		driver.findElement(By.id("user_password")).sendKeys(password);
		driver.findElement(By.id("sysverb_login")).click();
		
	}
	

}
