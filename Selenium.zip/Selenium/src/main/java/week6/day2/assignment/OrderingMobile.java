package week6.day2.assignment;
import org.apache.poi.sl.usermodel.Shadow;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class OrderingMobile extends ServiceNowSetUp {
	
	@Test
	public void orderingMobile() throws InterruptedException {
//		3. Click-All Enter Service catalog in filter navigator and press enter
		
	
		String all="return document.querySelector(\"body > macroponent-f51912f4c700201072b211d4d8c26010\").shadowRoot.querySelector(\"div > sn-canvas-appshell-root > sn-canvas-appshell-layout > sn-polaris-layout\").shadowRoot.querySelector(\"div.sn-polaris-layout.polaris-enabled > div.header-bar > sn-polaris-header\").shadowRoot.querySelector(\"#all\").click()";
		driver.executeScript(all);
		String serviceCatlog ="return document.querySelector(\"body > macroponent-f51912f4c700201072b211d4d8c26010\").shadowRoot.querySelector(\"div > sn-canvas-appshell-root > sn-canvas-appshell-layout > sn-polaris-layout\").shadowRoot.querySelector(\"div.sn-polaris-layout.polaris-enabled > div.header-bar > sn-polaris-header\").shadowRoot.querySelector(\"nav > div > sn-polaris-menu.can-animate.is-main-menu.is-open\").shadowRoot.querySelector(\"nav > div.sn-polaris-nav.all.can-animate.keyboard-navigatable > div.sn-tree-menu.sn-polaris-nav-content > div > div > sn-collapsible-list:nth-child(1)\").shadowRoot.querySelector(\"div > div > ul > li:nth-child(3) > span > a > span > span.label\").click()";
		wait.until(ExpectedConditions.jsReturnsValue(serviceCatlog));
		driver.executeScript(serviceCatlog);
//		4. Click on  mobiles
		String iframe= "return document.querySelector(\"body > macroponent-f51912f4c700201072b211d4d8c26010\").shadowRoot.querySelector(\"#gsft_main\").switchTo()";
		driver.executeScript(iframe);
		WebElement mobiles = driver.findElement(By.xpath("(//h2[contains(text(),'Mobiles')]/ancestor::a)[2]"));
		wait.until(ExpectedConditions.visibilityOf(mobiles));
		mobiles.click();
//		5.Select Apple iphone6s
		driver.findElement(By.xpath("//strong[text()='iPhone 6s']")).click();
//		6.Update color field to rose gold and storage field to 128GB
		driver.findElement(By.xpath("//button[text()='Try it']")).click();
		WebElement colour = driver.findElement(By.xpath("//select[@class='form-control cat_item_option ']"));
		Select selectColour= new Select(colour);
		selectColour.selectByVisibleText("Gold");
		WebElement storage = driver.findElement(By.xpath("(//select[@class='form-control cat_item_option '])[2]"));
		Select selectStorage= new Select(storage);
		selectStorage.selectByVisibleText("128");
//		7.Select  Order now option
		driver.findElement(By.xpath("//button[contains(text(),'Order Now')]")).click();
//		8.Verify order is placed and copy the request number
		String text=driver.findElement(By.xpath("//div[@class='notification notification-success']/span")).getText();
		String output="Thank you, your request has been submitted";
		if (text.equalsIgnoreCase(output)) {
			System.out.println("The order is placed successfully");
		}
		else {
			System.out.println("The order is not placed successfully");
		}
		String requestID = driver.findElement(By.xpath("//dt[text()='Request Number:�']/following::b")).getText();
		System.out.println("The request id is: "+requestID);
	}

}
