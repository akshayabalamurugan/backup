package week6.day2;
import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseClass {	
	ChromeDriver driver;
	WebDriverWait wait;
	String excelFileName="";
	   
	@Parameters({"url", "username", "password"})
	@BeforeMethod
	public void preCondition(String url, String username, String password) {
//		1. Launch URL "http://leaftaps.com/opentaps/control/login"
		WebDriverManager.chromedriver().setup();
		 driver= new ChromeDriver();
		driver.get(url);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		wait= new WebDriverWait(driver, Duration.ofSeconds(10));
//        2. Enter UserName and Password Using Id Locator
		driver.findElement(By.id("username")).sendKeys(username);
		driver.findElement(By.id("password")).sendKeys(password);
//        3. Click on Login Button using Class Locator
		driver.findElement(By.className("decorativeSubmit")).click();
//        4. Click on CRM/SFA Link
		driver.findElement(By.linkText("CRM/SFA")).click();
	}
	
	@AfterMethod
	public void postCondition() {
		driver.quit();
	}
	
	@DataProvider(name="data")
	public String[][] dataset() throws IOException {
	
//				data[0][0]="Telekom";
//				data[0][1]="Akshaya";
//				data[0][2]="Balamurugan";
//				data[0][3]="Akshaya";
//				data[0][4]="Telecommunication";
//				data[0][5]="I wanted to create a form as assignment";
//				data[0][6]="akshayabalamurugan12@gmail.com";
//				data[0][7]="91";
//				data[0][8]="1";
//				data[0][9]="9500194552";
		
		String[][] data= DataFromExcel.readData(excelFileName);
		return data;
	}
}
