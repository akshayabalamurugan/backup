package interviewpractice;

import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ReadDataFromExcel {

	public static void main (String[] args) throws IOException{
		
//		String excelName=  "WebTableValidation";
//		XSSFWorkbook workBook= new XSSFWorkbook("Data/"+excelName+".xlsx");
//		XSSFSheet workSheet= workBook.getSheetAt(0);
//		int rowCount= workSheet.getLastRowNum();
//		int colCount= workSheet.getRow(1).getLastCellNum();
//		String[][] data = new String[rowCount][colCount];
//		for (int i = 1; i <= rowCount; i++) {
//			XSSFRow row= workSheet.getRow(i);
//			for (int j = 0; j < colCount; j++) {
//				XSSFCell cell= row.getCell(j);
//			data[i-1][j]= cell.getStringCellValue();
//			System.out.println(data[i-1][j]);
//			}
//			
//		}
//		workBook.close();
		
		
	
	WebDriverManager.chromedriver().setup();	
	ChromeOptions options = new ChromeOptions();
	options.setHeadless(true);
	ChromeDriver driver=new ChromeDriver(options);
	driver.get("https://www.leafground.com/table.xhtml");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	String text = driver.findElement(By.xpath("//tbody[@id='form:j_idt89_data']//span[text()='Name']")).getText();
//	List<WebElement> tableEntryName = driver.findElements(By.xpath("//tbody[@id='form:j_idt89_data']//span[text()='Name']"));
//	List<String> names= new ArrayList<String>();
//	for (int i = 0; i < tableEntryName.size(); i++) {
//		String text = tableEntryName.get(i).getText();
//		names.add(text);
//		
//	}
	
	System.out.println(text);
	
	
	}
}
