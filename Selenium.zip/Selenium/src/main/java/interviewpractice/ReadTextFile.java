package interviewpractice;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class ReadTextFile {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		String fileName= "Data/input.txt";
		
		FileWriter fw= new FileWriter(fileName, true);
		BufferedWriter writer= new BufferedWriter(fw);
		writer.write("\r\n");
		writer.write("Akshaya");
		writer.write("\r\n");
		writer.write("Dharun");
		writer.write("\r\n");
		writer.write("Dhanush");
		writer.write("\r\n");
		writer.write("Parvathi");
		writer.write("\r\n");
		writer.write("end");
		writer.close();
		
		File file= new File (fileName);
		Scanner sc= new Scanner(file);
		while (sc.hasNextLine()== true) {
			System.out.println(sc.nextLine());
		}
		
		sc.close();
	}
}
