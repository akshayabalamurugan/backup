package interviewpractice;

import java.util.ArrayList;

public class Strings {
	
	public void reverseName(String input) {
		String output = null;
		for(int i=input.length()-1; i>=0; i--) {
		System.out.print(input.charAt(i));
		}
		}	

	
	public void seprateString(String input) {
		
		String a= input.replaceAll("[^0-9]", "");
		String b= input.replaceAll("[^a-zA-z]", "");
		String c= input.replaceAll("[0-9a-zA-Z]", "");
		
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		
	}
	
	public void numString (String input) {
		
		char ch;
		int sum=0;
		
		for (int i=0; i<input.length(); i++) {
			ch= input.charAt(i);
			if(Character.isDigit(ch)) {
				int n= Character.getNumericValue(ch);
				sum= sum+n;
			}
			
		}
//		String s= Integer.toString(sum);
//		output= input.replaceAll("[0-9]", "");
//		output= output.concat(s);
		
			System.out.println(sum);
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Strings ogj= new Strings();
//		ogj.reverseName("Akshaya");
//		ogj.seprateString("123abc,;)");
		ogj.seprateString("fname143 lname");
	}

}
