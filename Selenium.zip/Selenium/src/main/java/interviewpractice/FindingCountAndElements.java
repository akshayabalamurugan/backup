package interviewpractice;

import java.util.LinkedHashMap;

public class FindingCountAndElements {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String test = "$$ Welcome to 1st Automation Interview $$ +12324334";
//		char[] testArray= test.toCharArray();
//		 
//		LinkedHashMap<Character, Integer> testMap= new LinkedHashMap<Character, Integer>();
//		
//		for(int i= 0; i<test.length(); i++) {
//			
//			testMap.put(testArray[i], testMap.getOrDefault(testArray[i], 0)+1);
//		}
//		
//		System.out.println(testMap);
		
		String alp= test.replaceAll("[^a-zA-z]", "");
		int aplCount= alp.length();
		System.out.println(alp);
		System.out.println(aplCount);
		String number= test.replaceAll("[^0-9]", "");
		int numCount= number.length();
		System.out.println(number);
		System.out.println(numCount);
		String space= test.replaceAll("[^ ]", "");
		int spacCount= space.length();
		System.out.println(space);
		System.out.println(spacCount);
		String spec= test.replaceAll("[0-9a-zA-z ]", "");
		int specCount= spec.length();
		System.out.println(spec);
		System.out.println(specCount);
		
		
		
		

	}

}
