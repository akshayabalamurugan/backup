package interviewpractice;

import java.util.ArrayList;
import java.util.List;

public class Numbers {

	public  boolean isArmstrong(int num) {
		int temp;
		int rem;
		int count = 0;
		int output = 0;
		boolean isArmStrong = false;
		temp=num;
		while(temp!=0) {
			temp=temp/10;
			count++;
		}
		temp=num;
		while(temp!=0) {
			rem= temp%10;
			output= (int) (output+ Math.pow(rem, count));
			temp=temp/10;
		}
		if (output==num) {
			isArmStrong=true;
		} else {
			isArmStrong=false;
		}
		return isArmStrong;
	}
	
	public boolean isPrime (int num) {
		
		boolean isPrimeNum = false;
		for(int i=2;i<num;i++) {
			if((num%i)==0) {
				isPrimeNum=false;
				break;
			}
			else {
				isPrimeNum=true;
			}
		}
		return isPrimeNum;
		
	}
	
	public List<Integer> fibonacci(int count) {
		
		int num1 =0;
		int num2= 1;
		List<Integer> output= new ArrayList<Integer>();
		
	for(int i=0; i<count; i++) {
		int temp= num1+num2;
		output.add(temp);
		num1=num2;
		num2= output.get(i);
	}
		return output;
		
	}
	
	public ArrayList<Integer> findIntersection() {
		int[] arr1 = {3,2,11,4,6,7};
		int[] arr2 = {1,2,8,4,9,7};
		ArrayList<Integer> output= new ArrayList<Integer>();
		for (int i=0; i<arr1.length; i++) {
			for (int j=0; j<arr2.length; j++) {
				if(arr1[i]==arr2[j]) {
					output.add(arr2[j]);
				}
			}
		}
		return output;
		
	}
 	
	public ArrayList<Integer> findduplicates (int num[]) {
		
		
		ArrayList<Integer> output= new ArrayList<Integer>();
		
		for(int i=0; i<num.length; i++) {
			for (int j=i+1; j<num.length; j++) {
				if(num[i]==num[j] ){
					output.add(num[j]);
				}
			}
			
		}
		
		
		return output;
	}
	
	public static void main(String[] args) {
		int[] num ={1,2,2,6,7,3,4,4,5,5,6,7};
		Numbers obj= new Numbers();
//		System.out.println(obj.isArmstrong(153));
//		System.out.println(obj.isPrime(17));
//		System.out.println(obj.fibonacci(10));
//		System.out.println(obj.findIntersection());
		System.out.println(obj.findduplicates(num));
	}
	
	
}