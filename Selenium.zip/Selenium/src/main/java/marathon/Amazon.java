package marathon;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
public class Amazon {
	public static void main(String[] args) throws InterruptedException, IOException {
//		01) Launch Chome
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver= new ChromeDriver();
		driver.manage().window().maximize();
//	02) Load https://www.amazon.in/
		driver.get("https://www.amazon.in/");
//	03) Type "Bags" in the Search box
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys("Bags");
		Thread.sleep(3000);
//		04) Choose the third displayed item in the result 
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys(Keys.DOWN , Keys.DOWN , Keys.DOWN , Keys.ENTER);		Thread.sleep(5000);
//	05) Print the total number of results (like 30000)
		String iniCount = driver.findElement(By.xpath("//div[@class='a-section a-spacing-small a-spacing-top-small']/span")).getText();
	    String[] inicount1= iniCount.split(" ");
	    String newCount= inicount1[3].replace(",", "");
	    System.out.println(newCount);
//	06) Select the first 2 brands in the left menu
	driver.findElement(By.xpath("(//span[text()='Brand']//following::input[@type='checkbox'])[1]//following::i")).click();
	Thread.sleep(3000);
	driver.findElement(By.xpath("(//span[text()='Brands']//following::input[@type='checkbox'])[2]//following::i")).click();
//	    (like American Tourister, Generic)
//	07) Confirm the results have got reduced (use step 05 for compare)
	String finalCount = driver.findElement(By.xpath("//div[@class='a-section a-spacing-small a-spacing-top-small']/span")).getText();
    String[] finalcount1= finalCount.split(" ");
    String newCount1= finalcount1[3].replace(",", "");
    System.out.println(newCount1);
    if (Integer.parseInt(newCount)>Integer.parseInt(newCount1)) {
		System.out.println("The results are reduced after filtering");
	} else {
		System.out.println("The results are not reduced after filtering");
	}
//	08) Choose New Arrivals (Sort)
		driver.findElement(By.xpath("//span[text()='Sort by:']")).click();
		driver.findElement(By.linkText("Newest Arrivals")).click();
		Thread.sleep(3000);
//	09) Print the first resulting bag info (name, discounted price)
		String price1 = driver.findElement(By.xpath("(//span[@class='a-price-whole'])[1]")).getText();
		driver.findElement(By.xpath("(//span[@class='a-price-whole'])[1]")).click();
		Thread.sleep(3000);
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
	    driver.switchTo().window(tabs2.get(1));
		String price2 = driver.findElement(By.xpath("//div[@class='a-section']//span[@class='a-offscreen']")).getText();
//	12) Confirm the price on previous and this page are same 
		if (price1.endsWith(price2)) {
			System.out.println("the price on previous and this page are same ");
		} else {

			System.out.println("the price on previous and this page are not same ");
		}
//	13) Take screenshot and close
		File source = driver.getScreenshotAs(OutputType.FILE);
		 File target= new File("./amazon"+".png");
		 FileUtils.copyFile(source, target);
		 Thread.sleep(3000);
		 driver.quit();
	}
}