package marathon;



import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;


import io.github.bonigarcia.wdm.WebDriverManager;

public class RedBus {

	public static void main(String[] args) throws InterruptedException, IOException {
//	01) Launch Firefox / Chrome
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver=new ChromeDriver();	
//	02) Load https://www.redbus.in/
		driver.get("https://www.redbus.in/");
		driver.manage().window().maximize();
//	03) Type "Chennai" in the FROM text box
		driver.findElement(By.id("src")).clear();
		driver.findElement(By.id("src")).sendKeys("Chennai");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//li[text()='Chennai']")).click();
//	04) Type "Bangalore" in the TO text box
		driver.findElement(By.id("dest")).clear();
		driver.findElement(By.id("dest")).sendKeys("Bangalore");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//li[text()='Bangalore']")).click();
		Thread.sleep(1000);
//	05) Select tomorrow's date in the Date field
		driver.findElement(By.xpath("//label[text()='Date']")).click();
		driver.findElement(By.xpath("(//td[@class='current day'])/following::td")).click();
//	06) Click Search Buses
		driver.findElement(By.id("search_btn")).click();
		Thread.sleep(2000);
//	07) Print the number of buses shown as results (104 Buses found)
		driver.findElement(By.xpath("//i[@class='icon icon-close']")).click();
		Thread.sleep(1000);
		String totalbuses = driver.findElement(By.xpath("//span[@class='f-bold busFound']")).getText();
		System.out.println(totalbuses);
		Thread.sleep(1000);
//	08) Choose SLEEPER in the left menu 
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,250)", "");
		driver.findElement(By.xpath("//label[text()='SLEEPER']")).click();
		Thread.sleep(1000);
//	09) Print the name of the second resulting bus
		String secondBus = driver.findElement(By.xpath("(//div[contains(@class,'travels lh-24')])[2]")).getText();
		System.out.println(secondBus);
		Thread.sleep(1000);
//	10) Click the VIEW SEATS of that bus
		driver.findElement(By.xpath("(//div[text()='View Seats'])[2]")).click();
		Thread.sleep(1000);
//	11) Take screenshot and close browser
		 File source = driver.getScreenshotAs(OutputType.FILE);
		 File target= new File("./redbus"+".png");
		 FileUtils.copyFile(source, target);
		 driver.quit();

	}

}
