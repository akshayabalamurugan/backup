package marathon;
import java.io.File;
import java.io.IOException;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.edge.EdgeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
public class BookmyShow {
	public static void main(String[] args) throws InterruptedException, IOException {
//	01) Launch Edge / Chrome
		WebDriverManager.edgedriver().setup();
		EdgeDriver driver= new EdgeDriver();	
//	02) Load https://in.bookmyshow.com/
		driver.get("https://in.bookmyshow.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
//	03) Type the city as "Hyderabad" in Select City
		driver.findElement(By.xpath("//input[@class='sc-jvEmr elijMA']")).sendKeys("Hyderabad"+Keys.ENTER);
//	04) Confirm the URL has got loaded with Hyderabad 
		String currentUrl = driver.getCurrentUrl();
		System.out.println(currentUrl);
		if (currentUrl.contains("hyderabad")) {
			System.out.println("The URL is loaded with hyderabad");
			
		}
		else {
			System.out.println("The URL is not loaded with hyderabad");
		}
		Thread.sleep(1000);
//	05) Search for your favorite movie 
		
		driver.findElement(By.xpath("//span[@class='sc-jKVCRD jyFDAS']")).click();
		driver.findElement(By.xpath("//input[@class='sc-jvEmr elijMA']")).sendKeys("The Warriorr");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//span[@class='sc-hdPSEv kzaUOq']")).click();
		Thread.sleep(2000);
//	06) Click Book Tickets
		driver.findElement(By.xpath("//button[@class='sc-8f9mtj-0 sc-8f9mtj-1 sc-1vmod7e-0 gsJmXR']")).click();
		Thread.sleep(2000);
//	07) Print the name of the theater displayed first
		driver.findElement(By.id("wzrk-cancel")).click();
//	08) Click on the info of the theater
		String theater = driver.findElement(By.xpath("//div[@class='__title']/a")).getText();
		System.out.println(theater);
//	09) Confirm if there is a parking facility in the theater
		driver.findElement(By.className("venue-info-text")).click();
		Thread.sleep(5000);
		String parking=driver.findElement(By.xpath("//div[contains(text(),'Parking Facility')]")).getText();
		
		if (parking.contains("Parking Facility")) {
			System.out.println("The theater has Parking Facility");
		}
		else {
			System.out.println("The theater dont have Parking Facility");
		}
		Thread.sleep(5000);
//	10) Close the theater popup
		driver.findElement(By.className("cross-container")).click();
		Thread.sleep(2000);
//	11) Click on the first green (available) timing
		driver.findElement(By.xpath("//div[@class='showtime-pill-wrapper']//a")).click();
//	12) Click Accept
		driver.findElement(By.xpath("//div[contains(text(),'Accept')]")).click();
		Thread.sleep(1000);
//	13) Choose 1 Seat and Click Select Seats
		driver.findElement(By.id("pop_1")).click();
		driver.findElement(By.id("proceed-Qty")).click();
		Thread.sleep(2000);
//	14) Choose any available ticket and Click Pay
		driver.findElement(By.xpath("//a[@class='_available']")).click();
		driver.findElement(By.id("btnSTotal_reserve")).click();
		Thread.sleep(1000);
//	15) Print the sub total
		String subTotal = driver.findElement(By.className("__sub-total")).getText();
		System.out.println(subTotal);
		//	16) Take screenshot and close browser	
		 File source = driver.getScreenshotAs(OutputType.FILE);
		 File target= new File("./bookmyshow"+".png");
		 FileUtils.copyFile(source, target);
		 Thread.sleep(3000);
		 driver.quit();
	}
}