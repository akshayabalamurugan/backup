

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String input="1279";
		int output = 0;
		String temp=input;		
		while (temp.length()>1) {
			char[] charArray = temp.toCharArray();
			for (int i = 0; i < charArray.length; i++) {
				output= output+Character.getNumericValue(charArray[i]);
				temp= Integer.toString(output);
			}
			System.out.println(output);
			output=0;
		}
		
	}

}
