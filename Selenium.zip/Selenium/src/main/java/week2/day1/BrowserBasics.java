package week2.day1;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;
public class BrowserBasics {
	public static void main(String[] args) {
		// Call WebDriverMangaer to setup chromedriver
		WebDriverManager.chromedriver().setup();
		// Creating object for chromedriver
		ChromeDriver driver= new ChromeDriver();
		//launch url
		driver.get("http://leaftaps.com/opentaps/control/main");
		//maximise the page loaded
		driver.manage().window().maximize();
		//Input the username by finding the field with valid locator(used id because it was unique) 
		driver.findElement(By.id("username")).sendKeys("Demosalesmanager");
		//Input the password by finding the field with valid locator(used id because it was unique) 
		driver.findElement(By.id("password")).sendKeys("crmsfa");
		//Click the login button by finding the field with valid locator(used id because there was no whitespace)
		driver.findElement(By.className("decorativeSubmit")).click();
		//Check whether u have opened the rightpage by finding an expected element from the opened page
		//create a object of webelement and find the element from opened page
		WebElement logout=driver.findElement(By.className("decorativeSubmit"));
		// create a string and store the value of locator selected to verify the page
		String attribute=logout.getAttribute("value");
		// if the string value equals the value available in the locator, its verified that the page is correct
		if (attribute.equals("Logout")) {
			System.out.println("The page is logged in successfully");
		}
		else {
			System.out.println("Login is failed");
		}
		driver.findElement(By.linkText("CRM/SFA")).click();
		driver.findElement(By.linkText("Leads")).click();
		driver.findElement(By.linkText("Create Lead")).click();
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys("Cognizant");
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys("Akshaya");
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys("Balamurugan");
		//To automate dropdown create webelement and find the dropdown with locator
		WebElement source= driver.findElement(By.id("createLeadForm_dataSourceId"));
		//Convert the webelement to select class and create an object for select class
		Select dropdown= new Select(source);
		//with the select class object select the value from dropdown with select class methods (select by index, select by value,
		//select by visible text)
		dropdown.selectByVisibleText("Existing Customer");
		driver.findElement(By.className("smallSubmit")).click();
		String reassign=driver.getTitle();
		System.out.println(reassign);
		if (reassign.equals("View Lead | opentaps CRM")) {
			System.out.println("The view lead page is verified");
		}
		else {
			System.out.println("The view lead page is not verified");
		}
	}		
	}