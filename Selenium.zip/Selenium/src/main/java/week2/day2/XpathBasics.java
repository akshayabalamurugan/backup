package week2.day2;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class XpathBasics {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Go to https://www.zoomcar.com/in/bangalore (manually in chrome)
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver= new ChromeDriver();
//			1_ Write XPath for Placeholder by text
		driver.findElement(By.xpath("//div[contains(text(),'Pick Up City')]"));
//		1_ Write XPath for Placeholder by attribute 
		driver.findElement(By.xpath("//div[@class='placeholder']"));
//			2_ Write XPath for FIND CARS 
		driver.findElement(By.xpath("//button[contains(text(),'Find cars')]"));
		
		
//		a) Find the xpath for first name text box using the label
		driver.findElement(By.xpath("(//label[text()='First name:'])[3]/following::input"));
		
		driver.findElement(By.xpath("//div[contains(@class,'x-grid3-col-partyId')]/a"));



				

	}

}
