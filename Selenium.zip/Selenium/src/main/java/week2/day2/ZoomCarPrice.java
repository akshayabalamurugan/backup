package week2.day2;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ZoomCarPrice {

	public static void main(String[] args) {
//		1) Launch chrome
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver= new ChromeDriver();
//	2) Load https://www.zoomcar.com/in/bangalore
		driver.get("https://www.zoomcar.com/in/bangalore/");
		driver.manage().window().maximize();
//		

	}

}
