package week2.day2.assignments;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BondWithButtons {

	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver= new ChromeDriver();
		driver.get("http://leafground.com/pages/Button.html");
		driver.manage().window().maximize();
		String text = driver.findElement(By.id("home")).getText();
		driver.findElement(By.id("home")).click();
		String title = driver.getTitle();
		System.out.println(title);
		if (title.equals("TestLeaf - Selenium Playground")) {
			System.out.println("The button "+text+" navigates to home page");
		} else {
			System.out.println("The button "+text+" doesnt navigates to home page");
		}

	}

}
