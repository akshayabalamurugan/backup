package platform;
public class Solution {
	public static void main(String[] args) {
		

		String str="Testleaf-Software=Great-value!";
		String str1="";
		char c=0;
		for (int i = str.length()-1; i>=0; i--) {
		for (int j = 0; j < str.length(); j++) {
		 c = str.charAt(i);
			if(Character.isLetterOrDigit(i)==true) {
				c= str.charAt(j);
			}
			
		}
	
		str1+= c;
			
		}
System.out.println(str1);
	}
}

