package week4.day1;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
public class Frame {
	public static void main(String[] args) {
//		1_ Open Chrome
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver= new ChromeDriver();	
//		2_ Load https://www.w3schools.com/js/tryit.asp?filename=tryjs_confirm
		driver.get(" https://www.w3schools.com/js/tryit.asp?filename=tryjs_confirm");
		driver.manage().window().maximize();
//		3_ Click TryIt (not: this is inside frame)
	
		WebElement frame = driver.findElement(By.id("iframeResult"));
		driver.switchTo().frame(frame);
		driver.findElement(By.xpath("//button[text()='Try it']")).click();
		Alert alert = driver.switchTo().alert();
//		4_ Click Cancel on the alert
		alert.dismiss();
//		5_ Print the resulting text
		String text = driver.findElement(By.id("demo")).getText();
		System.out.println(text);
	}
}

