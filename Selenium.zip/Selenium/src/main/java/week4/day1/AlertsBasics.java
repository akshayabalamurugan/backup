package week4.day1;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
public class AlertsBasics {
	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver= new ChromeDriver();
		driver.get("http://www.leafground.com/pages/Alert.html");
		driver.manage().window().maximize();
		//inspecting simple dialog alert
		driver.findElement(By.xpath("//button[text()='Alert Box']")).click();
		Alert alert = driver.switchTo().alert();
		alert.accept();
		//inspecting confirm dialog alert
		driver.findElement(By.xpath("//button[text()='Confirm Box']")).click();
		alert.dismiss();
		String text2 = driver.findElement(By.id("result")).getText();
		System.out.println(text2);
		//inspecting prompt dialog alert
		driver.findElement(By.xpath("//button[text()='Prompt Box']")).click();
		alert.accept();
		String text = driver.findElement(By.id("result1")).getText();
		System.out.println(text);
		// inspecting simple dialog alert and retriving the test from the simple dialog alertbox
		driver.findElement(By.xpath("//button[text()='Line Breaks?']")).click();
		String text3 = alert.getText();
		System.out.println(text3);
		alert.accept();
	}
}
