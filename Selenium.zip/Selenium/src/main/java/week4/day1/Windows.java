package week4.day1;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
public class Windows {
	public static void main(String[] args) throws InterruptedException {
//		1) Open the chrome
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver=new ChromeDriver();
//		2) Login to leaftaps
		driver.get("http://leaftaps.com/opentaps/control/main");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.findElement(By.id("username")).sendKeys("Demosalesmanager");
		driver.findElement(By.id("password")).sendKeys("crmsfa");
		driver.findElement(By.className("decorativeSubmit")).click();
//		3) Click CRM/SFA link
		driver.findElement(By.linkText("CRM/SFA")).click();
//		4) Click Leads Link
		driver.findElement(By.linkText("Leads")).click();
//		5) Click Merge Leads Link
		driver.findElement(By.linkText("Merge Leads")).click();
//		6) Click the icon following the from lead
		driver.findElement(By.xpath("//span[text()='From Lead']/following::a")).click();
//		7) Switch to new window
		Set<String> windowHandles = driver.getWindowHandles();
		List<String> listWindowHandles= new ArrayList<String>(windowHandles);
		String window2 = listWindowHandles.get(1);
		driver.switchTo().window(window2);
		Thread.sleep(3000);
//		8) Enter the first name as Babu
		driver.findElement(By.name("firstName")).sendKeys("Babu");
//		9) Click Find Leads Button
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
//		10) Click on the first resulting lead
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']//a")).click();
//		11) Move the control back to first window
		String window1 = listWindowHandles.get(0);
		driver.switchTo().window(window1);
		System.out.println(driver.getTitle());
	}
}