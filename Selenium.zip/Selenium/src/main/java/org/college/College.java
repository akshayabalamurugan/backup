package org.college;

public class College {

	public void collegeName() {
		System.out.println("The college name is R.M.D. Engineering College");
	}
	public void collegeCode() {
		System.out.println("The code for R.M.D. Engineering College is 1115 ");
	}
	public void collegeRank() {
		System.out.println("The Rank of R.M.D. Engineering College is 5");
	}
	
}
