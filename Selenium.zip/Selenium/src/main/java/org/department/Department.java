package org.department;

import org.college.College;

public class Department extends College {

	public void deptName()  {
		System.out.println("The department available in college is EEE");
	}
}
