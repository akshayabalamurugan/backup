package org.system;

public class Computer {

	public void computerModel() {
		System.out.println("The computer model in Dell");
	}
}
