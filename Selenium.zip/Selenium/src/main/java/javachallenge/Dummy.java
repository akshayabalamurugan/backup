package javachallenge;

public class Dummy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
