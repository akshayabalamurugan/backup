package javachallenge;

public class Challenge2 {

	public static void main(String[] args) {
		int num=8;
		double root= Math.sqrt(num);
			
		

		System.out.println(root);
	}

}
