package week7.day2;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class RetryFailedCases implements IRetryAnalyzer {

	int maxRetry=0;
	
	public boolean retry(ITestResult result) {
	  if (maxRetry<1) {
		  maxRetry++;
		return true;
	}
		return false;
	}

}
