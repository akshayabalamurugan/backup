package javaprogram;

public class LengthOfLastWordOfString {

	public static void main(String[] args) {
	String input ="   fly me   to   the moon  ";
	String[] as= input.split(" ");
	String temp= as[as.length-1];
	System.out.println(temp.length());
	}	
	}

		
		
	
	
	

