package javaprogram;


public class IndexOfNonReapeatingCharacter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String input="leetcode";
		int output = 0;

		}
		}
