package javaprogram;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map.Entry;

public class MaximumOccurence {
	public static void main(String[] args) {
		int[] input= {3,2,3};
		HashMap<Integer, Integer> inputMap= new HashMap<Integer, Integer>();
		for (int i = 0; i < input.length; i++) {
			inputMap.put(input[i], inputMap.getOrDefault(input[i], 0) +1);
		}
		for (Entry<Integer, Integer> entry : inputMap.entrySet()) {
		if (entry.getValue()== Collections.max(inputMap.values())) {
		System.out.println(entry.getKey());	
	}
}
	}
}
