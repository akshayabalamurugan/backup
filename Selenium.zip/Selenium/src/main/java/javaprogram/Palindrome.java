package javaprogram;

public class Palindrome {

	public static void main(String[] args) {
		
		String input = "A man, a plan, a canal: Panama";
		input= input.replaceAll("[^a-zA-z]", "");
		boolean isPalindrome = false;
		String input2 ="";
	for (int i = input.length()-1; i >=0; i--) {
		input2 = input2+ input.charAt(i);
	}	
	if (input2.equalsIgnoreCase(input)) {
		isPalindrome=true;
	}else {
		isPalindrome=false;
	}
		System.out.println(isPalindrome);
		
	}
}
