package javaprogram;

import java.util.Collections;
import java.util.HashMap;


public class IsNumberRepeated {

	public static void main(String[] args) {
		int[] input = {1,1,1,3,3,4,3,2,4,2};
		boolean isrepeated = false;
		HashMap<Integer, Integer> inputMap= new HashMap<Integer, Integer>();
		for (int i = 0; i < input.length; i++) {
			inputMap.put(input[i], inputMap.getOrDefault(input[i], 0)+1);
		}
			int value= Collections.max(inputMap.values());
			if (value>1) {
				isrepeated=true;
			}
			else {
				isrepeated=false;
			}
		
		System.out.println(isrepeated);
	}
	
}
