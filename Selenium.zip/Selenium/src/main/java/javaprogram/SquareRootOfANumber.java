package javaprogram;

public class SquareRootOfANumber {
	
	public static void main(String[] args) {
		int x= 625;
		double t;
		double sqroot=x/2;
		do {
			t=sqroot;
			sqroot= (t+(x/t))/2;	
		} while ((t-sqroot)!=0);
		System.out.println((int)sqroot);
	}
}
