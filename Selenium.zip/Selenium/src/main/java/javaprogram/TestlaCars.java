package javaprogram;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map.Entry;

public abstract class TestlaCars {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String input= "tesla cars";
		char[] inputArray= input.toCharArray();
		
		LinkedHashMap<Character, Integer> inputMap= new LinkedHashMap<Character, Integer>();
		LinkedHashMap<Character, Integer> duplicateMap= new LinkedHashMap<Character, Integer>();
		LinkedHashMap<Character, Integer> maxMap= new LinkedHashMap<Character, Integer>();
		for (int i = 0; i < inputArray.length; i++) {
			inputMap.put(inputArray[i], inputMap.getOrDefault(inputArray[i], 0)+1);
		}
		System.out.println(inputMap);
		for (Entry <Character, Integer> entry : inputMap.entrySet()) {
			
			if (entry.getValue()==Collections.max(inputMap.values())) {
			
				duplicateMap.put(entry.getKey(), entry.getValue());
			}
			if (entry.getValue()==Collections.min(inputMap.values())) {
				
				maxMap.put(entry.getKey(), entry.getValue());
			}
			
		}
System.out.println(duplicateMap);
System.out.println(maxMap);
	}

}
