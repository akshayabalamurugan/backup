package javaprogram;

public class InstanceAndOccurence {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] inputArray= {1,2,3,1};
		int k=3;
		boolean isInstance = false;
		
	}
}
