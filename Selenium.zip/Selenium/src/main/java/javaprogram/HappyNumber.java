package javaprogram;

public class HappyNumber {

	public static void main(String[] args) {
		
		int number= 19;
		
		
		
	}	

}
