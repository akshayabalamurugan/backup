package marathon3;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class CreateNewOpportunity extends BaseClass {
	
	@BeforeTest
	public void browserName() {
		browserName="chrome";
	}
	
	@Test
	public void createNewOpportunity () throws InterruptedException {

//			2. Click on toggle menu button from the left corner
		driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
//			3. Click view All and click Sales from App Launcher
		driver.findElement(By.xpath("//button[text()='View All']")).click();
		driver.findElement(By.xpath("//p[text()='Sales']")).click();
//			4. Click on Opportunity tab 
		driver.findElement(By.xpath("//a[@class='slds-button slds-button_reset']")).click();
//			5. Click on New button
		WebElement findElement = driver.findElement(By.xpath("//span[text()='New Opportunity']"));
		driver.executeScript("arguments[0].click();", findElement);
//			6. Enter Opportunity name as 'Salesforce Automation by *Your Name*,Get the text and Store it 
		driver.findElement(By.xpath("//label[text()='Opportunity Name']/following::input")).sendKeys("Salesforce Automation by Akshaya");
//			7. Choose close date as Today
		Thread.sleep(2000);
		driver.findElement(By.xpath("//label[text()='Close Date']/following::input")).click();
		driver.findElement(By.xpath("//span[text()='4']")).click();
//			8. Select 'Stage' as Need Analysis
		driver.findElement(By.xpath("//button[contains(@class,'slds-combobox__input slds-input_faux')]")).click();
		driver.findElement(By.xpath("//span[@title='Needs Analysis']")).click();
//			9. click Save and VerifyOppurtunity Name
		driver.findElement(By.xpath("//button[text()='Save']")).click();
		String text = driver.findElement(By.xpath("//div[text()='Opportunity']//following::lightning-formatted-text")).getText();
		System.out.println("The Oppurtunity name is "+text);
	}

}
