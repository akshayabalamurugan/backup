package marathon2;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import io.github.bonigarcia.wdm.WebDriverManager;
public class CreateNewOpportunity {
	public static void main(String[] args) throws InterruptedException {
//			1. Login to https://login.salesforce.com
		WebDriverManager.chromedriver().setup();
		ChromeOptions options= new ChromeOptions();
		options.addArguments("--disable-notifications");
		ChromeDriver driver= new ChromeDriver(options);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.get("https://login.salesforce.com/");
		driver.manage().window().maximize();
		driver.findElement(By.id("username")).sendKeys("ramkumar.ramaiah@testleaf.com");
		driver.findElement(By.id("password")).sendKeys("Password$123");
		driver.findElement(By.id("Login")).click();
//			2. Click on toggle menu button from the left corner
		driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
//			3. Click view All and click Sales from App Launcher
		driver.findElement(By.xpath("//button[text()='View All']")).click();
		driver.findElement(By.xpath("//p[text()='Sales']")).click();
//			4. Click on Opportunity tab 
		driver.findElement(By.xpath("//a[@class='slds-button slds-button_reset']")).click();
//			5. Click on New button
		WebElement findElement = driver.findElement(By.xpath("//span[text()='New Opportunity']"));
		driver.executeScript("arguments[0].click();", findElement);
//			6. Enter Opportunity name as 'Salesforce Automation by *Your Name*,Get the text and Store it 
		driver.findElement(By.xpath("//label[text()='Opportunity Name']/following::input")).sendKeys("Salesforce Automation by Akshaya");
//			7. Choose close date as Today
		Thread.sleep(2000);
		driver.findElement(By.xpath("//label[text()='Close Date']/following::input")).click();
		driver.findElement(By.xpath("//span[text()='4']")).click();
//			8. Select 'Stage' as Need Analysis
		driver.findElement(By.xpath("//button[contains(@class,'slds-combobox__input slds-input_faux')]")).click();
		driver.findElement(By.xpath("//span[@title='Needs Analysis']")).click();
//			9. click Save and VerifyOppurtunity Name
		driver.findElement(By.xpath("//button[text()='Save']")).click();
		String text = driver.findElement(By.xpath("//div[text()='Opportunity']//following::lightning-formatted-text")).getText();
		System.out.println("The Oppurtunity name is "+text);
		driver.quit();
	}

}
