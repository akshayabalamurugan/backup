import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ExcelTest {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String file="Data\\WebTableValidation.xlsx";
		XSSFWorkbook workbook= new XSSFWorkbook(file);
		XSSFSheet worksheet = workbook.getSheetAt(0);	
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver= new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.findElement(By.xpath("//i[@class='pi pi-table layout-menuitem-icon']")).click();
		driver.findElement(By.xpath("(//span[text()='Table'])[2]//parent::a")).click();
		List<WebElement> nameList = driver.findElements(By.xpath("//tbody[@class='ui-datatable-data ui-widget-content']//following::span[text()='Name']//parent::td"));
		List<WebElement> countryList = driver.findElements(By.xpath("//tbody[@class='ui-datatable-data ui-widget-content']//following::span[text()='Country']//parent::td"));
		for (int i = 0; i < nameList.size(); i++) {
			XSSFRow row= worksheet.getRow(i);
				XSSFCell cell= row.getCell(i);
				 String name = nameList.get(i).getText();
				 String country= countryList.get(i).getText();
				cell.setCellValue(name);
				System.out.println(cell.getStringCellValue());
		}
		
		HttpURLConnection url;
		int response;
		
		
		
		
	workbook.close();
			
	}

}
