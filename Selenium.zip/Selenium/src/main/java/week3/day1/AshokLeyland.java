package week3.day1;

public class AshokLeyland extends Truck {
	
	public void dropLoad() {
		System.out.println("The load is dropped");
	}

}
