package week3.day1.assignment5;

public abstract class MultipleLangauge {

	public void python() {
		System.out.println("The language is python");
	}
	public abstract void ruby();
}
