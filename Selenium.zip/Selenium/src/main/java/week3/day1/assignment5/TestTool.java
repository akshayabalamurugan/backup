package week3.day1.assignment5;

public interface TestTool {

	public void Selenium();
}
