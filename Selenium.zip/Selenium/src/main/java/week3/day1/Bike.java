package week3.day1;

public class Bike extends Vehicle {

	public void applyFrontBrake() {
		System.out.println("The brake is applied");
	}
	
}
