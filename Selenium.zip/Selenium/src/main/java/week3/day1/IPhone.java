package week3.day1;

public class IPhone implements Mobile {

	public String sendSMS(int number) {
		String message = null;
		return message;
	}

	public void dialNumber(int number) {
		// TODO Auto-generated method stub
		
	}

	public void switchOn() {
		// TODO Auto-generated method stub
		
	}
	

}
