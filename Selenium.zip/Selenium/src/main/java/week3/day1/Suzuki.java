package week3.day1;

public class Suzuki extends Bike {

	public void adjustMirror() {
		
		System.out.println(" The mirror is adjusted");
	}
}
