package week3.day1;

public class MyVehicle extends Suzuki {
	
	public static void main(String[] args) {
		
		Suzuki mybike= new Suzuki();
		mybike.adjustMirror();
		
		Truck alTruck= new Truck();
		
		alTruck.startvehicle();
		alTruck.startvehicle("Switched on");

		
	}

	
}
