package week3.day1;

public class Vehicle {
	
	public void startVehicle() {
	System.out.println("The vehicle is started");
	}
	
	public void startvehicle(String saver) {
		System.out.println("The vehicle is started with saver switched on");
	}
	
	public void powerOff() {
		System.out.println("The vehicle is switched off");
	}

}
