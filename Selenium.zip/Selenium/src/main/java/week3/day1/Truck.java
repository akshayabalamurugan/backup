package week3.day1;

public class Truck extends Vehicle {

	public void loadTruck() {
		System.out.println("The truck is loaded");
	}
		
		public void startvehicle() {
			System.out.println("The vehicle is started with saver switched off");
		}
		
	
	
}
