package week3.day1;

public interface Mobile {

//	Write 3 methods (abstract) - sendSMS, dialNumber, switchOn
	
	public String sendSMS(int number);
	public void dialNumber(int number);
	public void switchOn();
	
	
}
