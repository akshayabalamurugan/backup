package week3.day1.assignment3;

public class BankInfo {	
	public void saving() {
		System.out.println("The account opened is Savings Account");
	}
	public void fixed() {
		System.out.println("The account opened in Fixed Account");
	}
	public void deposit() {
		System.out.println("The purpose for the bank account is to deposit");
	}

}
