package week3.day2;
import java.util.LinkedHashSet;
import java.util.Set;

public class RemoveDuplicates {
public static void main(String[] args) {
	String companyName = "google";
	String finalname="";
	char[] charCompanyName= companyName.toCharArray();
	Set<Character> name= new LinkedHashSet<Character>();
	for (int i = 0; i < charCompanyName.length; i++) {
	boolean add = name.add(charCompanyName[i]);	
	if (add==true) {
		finalname= finalname+charCompanyName[i];
	}
	}
	System.out.println(finalname);	
	}
}

