package week3.day2.assignment;
import java.util.LinkedHashSet;
import java.util.Set;
public class RemoveDuplicates {
	public static void main(String[] args) {
		//	 Use the declared String text as input
		String text = "We learn java basics as part of java sessions in java week1";	
		// Convert the input string to string array 	
		String textArray[]= text.split(" ");
		//declare an empty string
		String finalresult="";
		//create a linked hash set so string is displayed as FIFO format
		Set<String> text2= new LinkedHashSet<String>();
		//iterate through the string array and add each non duplicate item to the set
		for (int i = 0; i < textArray.length; i++) {
		//check whether all non duplicate items of string array are added to the set
		boolean add = text2.add(textArray[i]);
		//If add is true, add the string element from array to an empty string and concat with a space
		if (add==true) {
		finalresult= finalresult+textArray[i].concat(" ");
		}
		}
		System.out.println(finalresult);
	}
}
