package week3.day2.assignment;


import java.util.LinkedHashMap;
import java.util.Map;

public class FirstMostDuplicate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String input= "abbaba";
		char[] charArray = input.toCharArray();
		
Map<Character,Integer> newMap= new LinkedHashMap<Character,Integer>();
for (int i = 0; i < charArray.length; i++) {
	newMap.put(charArray[i], newMap.getOrDefault(charArray[i], 0)+1);		
	}
System.out.println(newMap);

	}
}
	


	


