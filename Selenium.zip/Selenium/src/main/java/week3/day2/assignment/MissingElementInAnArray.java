package week3.day2.assignment;





public class MissingElementInAnArray {
	public  static void main(String[] args) {
		int[] arr = {1,2,3,4,7,6,8};
		System.out.println(arr);
	
		

	}
 }
