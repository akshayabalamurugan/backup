package week3.day2.assignment;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import io.github.bonigarcia.wdm.WebDriverManager;
public class ImplementList {
	public static void main(String[] args) throws InterruptedException {
//			1. Launch the URL https://www.ajio.com/
		WebDriverManager.chromedriver().setup();
		ChromeOptions options= new ChromeOptions();
		options.addArguments("--disabled--notifications");
		ChromeDriver driver= new ChromeDriver(options);
		driver.get("https://www.ajio.com/");
		driver.manage().window().maximize();
//			2. In the search box, type as "bags" and press enter
		driver.findElement(By.xpath("//input[@name='searchVal']")).sendKeys("Bags", Keys.ENTER);
//			3. To the left  of the screen under " Gender" click the "Men"
		driver.findElement(By.xpath("//label[contains(text(),'Men')]")).click();
		Thread.sleep(3000);
//			4. Under "Category" click "Fashion Bags"
		driver.findElement(By.xpath("//label[contains(text(),'Fashion Bags')]")).click();
		Thread.sleep(3000);
//			5. Print the count of the items Found.
		String text = driver.findElement(By.xpath("//div[@class='length']")).getText();
		System.out.println(text);
//			6. Get the list of brand of the products displayed in the page and print the list.	
		List<WebElement> brands = driver.findElements(By.xpath("//div[@class='brand']"));
		Set<String> newBrands= new HashSet<String>();
		for (int i = 0; i < brands.size(); i++) {
			 String text2 = brands.get(i).getText();
			newBrands.add(text2);
		}
		int brandSize = newBrands.size();
		System.out.println("No. of brands available is :"+brandSize);
		System.out.println("The brands available are: ");
		System.out.println(newBrands);
//			7. Get the list of names of the bags and print it
		List<WebElement> brandName = driver.findElements(By.xpath("//div[@class='nameCls']"));
		int brandNameSize = brandName.size();
		System.out.println("No. of products available is :"+brandNameSize);
		System.out.println("The products available are: ");
		for (int i = 0; i < brandName.size(); i++) {
			String text3 = brandName.get(i).getText();
			System.out.println(text3);
		}
	}
}
