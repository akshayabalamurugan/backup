package week3.day2.assignment;
import java.util.LinkedHashSet;
import java.util.Set;
public class FindIntersection {
	public static void main(String[] args) {
		int nums1[]= {3,2,11,4,6,7};
		int nums2[]={1,2,8,4,9,7};
		Set<Integer> nums3= new LinkedHashSet<Integer>();
		for (int i = 0; i < nums2.length; i++) {
			nums3.add(nums1[i]);
			boolean add = nums3.add(nums2[i]);
			if (add==false) {
				System.out.println(nums2[i]);
			}
		}

	}

}
