package week3.day2;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
public class MobilePrice {
	public static void main(String[] args) {
//			1) Go to https://amazon.in
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver= new ChromeDriver();
		driver.get("https://amazon.in");
		driver.manage().window().maximize();
//			2) Type phones
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys("Phones" + Keys.ENTER);
//			3) Print price of every phone
		List<WebElement> mobilePrice = driver.findElements(By.xpath("//span[@class='a-price-whole']"));
		List<Integer> lowPrice= new ArrayList<Integer>();
		 System.out.println("The list of mobile price is:");
		for (int i = 0; i < mobilePrice.size(); i++) {	
			 String text = mobilePrice.get(i).getText(); 
			 text= text.replace(",", "");
			 int price = Integer.parseInt(text);
			 System.out.println(price);
			 lowPrice.add(price);
		}
//			4) Print the lowest price !
		Collections.sort(lowPrice);
		System.out.println("The lowest mobile price is: " +lowPrice.get(0));			
	}
}