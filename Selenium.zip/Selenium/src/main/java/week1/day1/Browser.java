package week1.day1;

import week1.day2.Chrome;

public class Browser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Chrome phoneName= new Chrome();
		
	System.out.println(phoneName.getName());
		}

}
