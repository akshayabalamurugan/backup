package week1.day1;

public class Firefox {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*
		 * Int-> no quotes
		 * float-> no quotes
		 * boolean -> no quotes
		 * char-> single quotes
		 * String-> Double quotes
		 * 
		 * Primitive Data types- Int, float,boolean, char, double (Not used)
		 * Non Primitive data types= String and Array
		 * 
		 * Primitive Data types starts with lower case
		 * Non-Primitive Data types starts with upper case
		 * 
		 * Non-Primitive Data types are classes in java and Primitive Data types are keyword
		 */
		
		float version=(float) 100.2; 
		String name= "firefox";	
		boolean visible= true;
		int year= 1998;
		char logo='m';
		
		System.out.println("Details of firefox:");
		System.out.println(version);
		System.out.println(name);		
		System.out.println(visible);
		System.out.println(year);
		System.out.println(logo);
	}

}
