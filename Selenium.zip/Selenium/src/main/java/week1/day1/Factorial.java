package week1.day1;

public class Factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int value=1;
		int n=5;
		for (int i = 1; i<=n; i++) {
			   value= value*i;	 
		}
		System.out.println(value);
		
	}
}
