package week1.day1;

public class OddOrEven {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n= 100;			
		if (n%2==0) {
			System.out.println("The number is an even number");		
		}
		else if (n%3==0) {
			System.out.println("The number is odd number");		
		}
	}
}
