package week1.day1;

public class FirstCode {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Welcome test Leaf to learn selenium");

	}

}
