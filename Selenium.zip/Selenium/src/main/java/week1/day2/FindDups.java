package week1.day2;
import java.util.Arrays;
public class FindDups {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int data[]= {14,12,13,11,15,14,18,16,17,19,18,17,14,20};
		Arrays.sort(data);
		System.out.println("The duplicates are:");
		for (int i = 0; i < data.length-1; i++) {
			if (data[i]==data[i+1]) {	
				System.out.println(data[i]);		
			}			
		}
	}
}
