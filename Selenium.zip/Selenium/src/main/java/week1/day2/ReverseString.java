package week1.day2;

public class ReverseString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str= "hello";
		char[] word=str.toCharArray();
		for (int i = word.length-1; i>=0; i--) {
			System.out.print(word[i]);		
		}	
	}

}
