package week1.day2;
public class FindCharCount {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
String str="Akshaya";
char x='a';
int count=0;
String str1=str.toLowerCase();
char[] word= str1.toCharArray();
for (int i = 0; i < word.length; i++) {
	if (x==word[i]) {
		count++;
	}
}
System.out.println(count);
}
}
