package week1.day2.assignments.optional;
public class Calculator {
public int add(int num1, int num2, int num3) {
	int num4= num1+num2+num3;
	return num4;	
	}
public int sub(int num1, int num2) {
	int num3= num1+num2;
	return num3;
	}
public double mul(double num1, double num2) {
	double num3= num1*num2;
	return num3;
	}
public float divide(float num1, float num2) {
	float num3= num1/num2;
	return num3;	
}
}
