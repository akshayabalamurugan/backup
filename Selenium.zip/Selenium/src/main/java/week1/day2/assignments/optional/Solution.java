package week1.day2.assignments.optional;


public class Solution {
		public static void main (String[] args) {
		    long rem;
		    long num=153;
		    long result=0;
	      	int digits=0;
	      	long temp=num;
	      	
	      while(temp !=0){
	    	  temp= temp/10;
	        digits++;
	      }
	      
	      temp=num;
	      
	      while (temp>0) {
	    	  rem=temp%10;
		        result= (long) (result+ Math.pow(rem, digits));
		        temp=temp/10;
		   
	      }
	      temp=num;
	      System.out.println(temp);
	   
			}
	
	}