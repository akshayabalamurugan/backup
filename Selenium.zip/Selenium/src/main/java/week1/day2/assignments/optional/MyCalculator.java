package week1.day2.assignments.optional;
public class MyCalculator {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calculator x = new Calculator();;
		System.out.println(x.add(19,35,35));
		System.out.println(x.sub(86,70));
		System.out.println(x.mul(2432.1,7343));
		System.out.println(x.divide((float)9883.1,(float)8374.9));
	}
}
