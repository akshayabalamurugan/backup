package week1.day2;

public class Chrome {

	public String getName() {
		return "iphone13";
		
	}
	}

