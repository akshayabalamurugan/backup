package week1.day2;
import java.util.Arrays;
public class FindMinMax {
	public static void main(String[] args) {
		// TODO Auto-generated method stub	
		int value[]= {46,87,-23,-43,0,88,99};		
		Arrays.sort(value);		
		int xyz= value.length;		
		int min= value[0];
		System.out.println("The min value is:"+min);		
		int max= value[xyz-1];
		System.out.println("The min value is:"+max);	
	}
}
